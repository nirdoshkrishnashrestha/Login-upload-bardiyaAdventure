
This version is '1.03'
============================================================
For installation, please open folder "document".
go to "index.html". Read "installation" section.
============================================================

==v1.03== 03/05/2012
* Improved twitter shortcode 
* Improved Filter Portfolio in IE7
* Fixed Portfolio/Dropcap
* Fixed Footer Gallery
++++Modified files from v1.01++++
+ grandcollege/include/plugin/twitter-shortcode.php
+ grandcollege/include/plugin/page-item.php
+ grandcollege/include/plugin/shortcode-generator.php
+ grandcollege/search.php
+ grandcollege/single-course.php
+ grandcollege/style.css
+ grandcollege/include/goodlayers-option.php
+ grandcollege/javascript/jquery.cycle.js
+ grandcollege/javascript/gdl-script.js

==v1.02== 06/04/2012
* Improved twitter shortcode 
* Improved Filter Portfolio in IE7
* Fixed Portfolio/Dropcap
* Fixed Footer Gallery
++++Modified files from v1.01++++
+ grandcollege/include/plugin/ultity.php
+ grandcollege/include/plugin/page-item
+ grandcollege/stylesheet/ie7-style.css
+ grandcollege/page.php
+ grandcollege/style-custom.php
+ grandcollege/style.css
+ grandcollege/include/goodlayers-option.php
+ grandcollege/javascript/jquery.cycle.js

==v1.01== 15/03/2012
* Improved IE7 supported
* Added shadow on container
++++Modified files from v1.00++++
+ grandcollege/header.php
+ grandcollege/stylesheet/ie7-style.css
+ grandcollege/page.php
+ grandcollege/style-custom.php
+ grandcollege/style.css
+ grandcollege/include/goodlayers-option.php

==v1.00== 14/03/2012
* initial released 